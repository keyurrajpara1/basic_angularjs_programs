<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<title></title>
	<script type="text/javascript" src="angular.min.js"></script>
</head>
<body>
<div>
	Plain Text : {{10+20}}
</div>
<div ng-app="">
	Expression : {{10+20}}
</div>
</body>
</html>